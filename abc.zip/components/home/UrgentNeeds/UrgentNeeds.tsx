'use client';
import Styles from "./style.module.css";
import { Col, Container, Row } from 'react-bootstrap';
import CustomImage from '@/utlis/imagefunction';
import Link from "next/link";
import { useGlobalContext } from "@/context/global_context";

interface UrgentNeedsSectionData {
    urgent_needs_image?: string;
    urgent_title?: string;
    urgent_needs_description?: string;
    urgent_button?: string;
    urgent_button_link?: string;
}
interface UrgentNeedItem {
    urgent_need_title?: string;
    urgent_need_slug?: string;
}

interface UrgentNeedsProps {
    sectionData: UrgentNeedsSectionData | undefined;
    urgentNeeds?: UrgentNeedItem[] | null;
}

const mediaBaseURL = process.env.NEXT_PUBLIC_MEDIA_URL;

const UrgentNeeds = ({ sectionData, urgentNeeds }: UrgentNeedsProps) => {
    const {commonData} = useGlobalContext();
    if (!sectionData) return null;

    return (
        <div className={Styles.urgentNeeds_section}>
            <Container>
                <Row className="align-items-center gx-lg-0 rowGap">
                    <Col lg={7}>
                        {sectionData.urgent_needs_image && (
                            <CustomImage
                                src={`${mediaBaseURL}/uploads/page_image/${sectionData.urgent_needs_image}`}
                                alt="Urgent Needs"
                                width={600}
                                height={400}
                                style={{ objectFit: 'cover' }}
                                className={Styles.urgentNeeds_image}
                            />
                        )}
                    </Col>
                    <Col lg={5} className="align-self-center">
                        <div className={`urgentNeeds_content ${Styles.urgentNeeds_content}`}>
                            {sectionData.urgent_title && (
                                <h2 
                                    dangerouslySetInnerHTML={{
                                        __html: sectionData.urgent_title,
                                    }}
                                />
                            )}
                            {urgentNeeds && urgentNeeds.length > 0 ? (
                                <ul>
                                    {urgentNeeds.map((item, index) => (
                                        <li key={`${item.urgent_need_slug || "urgent-need"}-${index}`}>
                                            <Link href={`/urgent-needs/${item.urgent_need_slug || ""}`}>
                                                {item.urgent_need_title}
                                            </Link>
                                        </li>
                                    ))}
                                </ul>
                            ) : sectionData.urgent_needs_description && (
                                <div
                                    dangerouslySetInnerHTML={{
                                        __html: sectionData.urgent_needs_description,
                                    }}
                                />
                            )}
                            {sectionData.urgent_button && (
                                <Link 
                                    href="/urgent-needs"
                                    className={Styles.button}
                                    aria-label="About Page Button"
                                >
                                    {sectionData.urgent_button} <span className='screen-reader-text'>{commonData?.site_title || "ABC India"}</span>
                                </Link>
                            )}
                        </div>
                    </Col>
                </Row>
            </Container>
        </div>
    );
}
export default UrgentNeeds;
