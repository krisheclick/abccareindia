import CustomImage from "@/utlis/imagefunction";
import Styles from "./style.module.css"
import Link from "next/link";
interface EventItem {
    poster?: string;
    date?: string;
    title?: string;
    slug?: string;
    description?: string;
}
const EventCard = ({ poster, date, title, slug, description }: EventItem) => {
    const dateObj = new Date(date ?? '');
    function getOrdinal(day: number): string {
        if (day > 3 && day < 21) return "th";

        switch (day % 10) {
            case 1: return "st";
            case 2: return "nd";
            case 3: return "rd";
            default: return "th";
        }
    }

    const day = dateObj.getDate();

    const formattedDate =
        `${day}${getOrdinal(day)} ` +
        dateObj.toLocaleDateString("en-GB", {
            month: "long",
        }) +
        ` ${dateObj.getFullYear()}`;
    return (
        <div className={`event_card ${Styles.card}`}>
            <CustomImage
                className={Styles.card_image}
                src={poster}
                alt={title}
            />
            <div className={Styles.event_content}>
                <div className={`event_date ${Styles.date}`}>{formattedDate}</div>
                <div className={Styles.title}>{title}</div>
                <div className={Styles.card_content}
                    dangerouslySetInnerHTML={{ __html: description || '' }}
                />
                <div className={Styles.card_btn_wrap}>
                    <Link href={`${process.env.NEXT_PUBLIC_ENV_URL}/events/${slug}`} className={`btn btn-primary ${Styles.card_btn}`}>View More</Link>
                </div>
            </div>
        </div>
    )
}
export default EventCard;